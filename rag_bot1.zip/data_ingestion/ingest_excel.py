import os, sys, pandas as pd
from dotenv import load_dotenv
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from utils.logger import get_logger

load_dotenv()
log = get_logger(__name__)

EXCEL_FILE   = "data/Issue Log.xlsx"
SHEET        = 0
CONTENT_COLS = ["Description", "Resolution", "Number"]
PERSIST_DIR  = "chroma_db_openai"
EMB_MODEL    = "text-embedding-3-large"
CHUNK, OVERL = 1000, 150

def ingest():
    if not os.getenv("OPENAI_API_KEY"):
        log.error("OPENAI_API_KEY missing in .env"); sys.exit(1)
    if not os.path.exists(EXCEL_FILE):
        log.error(f"Excel file not found: {EXCEL_FILE}"); sys.exit(1)

    df = pd.read_excel(EXCEL_FILE, sheet_name=SHEET)
    for col in df.select_dtypes(include=["datetime64"]).columns:
        df[col] = df[col].dt.strftime("%Y-%m-%d")
    log.info("Loaded %d rows", len(df))

    docs = []
    for _, row in df.iterrows():
        pc = f"Incident Number: {row['Number']}\n\nIssue Description: {row['Description']}\n\nResolution: {row['Resolution']}"
        meta = {c.replace(" ", "_"): row[c] for c in df.columns if c not in CONTENT_COLS and pd.notna(row[c])}
        docs.append(Document(page_content=pc, metadata=meta))

    splitter = RecursiveCharacterTextSplitter(chunk_size=CHUNK, chunk_overlap=OVERL)
    chunks = splitter.split_documents(docs)
    embeddings = OpenAIEmbeddings(model=EMB_MODEL)
    Chroma.from_documents(chunks, embeddings, persist_directory=PERSIST_DIR)
    log.info("Ingestion complete – %d chunks stored.", len(chunks))

if __name__ == "__main__":
    ingest()
