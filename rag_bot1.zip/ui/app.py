import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import streamlit as st
from dotenv import load_dotenv
from retrievers.rag_pipeline import load_rag_pipeline

# --- Load environment variables ---
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '.env'))

# --- Streamlit page setup ---
st.set_page_config(page_title="AI Issue Resolution Assistant", page_icon="🤖", layout="wide")
st.title("🤖 AI Issue Resolution Assistant")
st.info("Chatbot uses SAP EWM logs to provide resolution summaries.")

# --- Load RAG pipeline ---
qa_chain = load_rag_pipeline()

# --- Session state for chat history ---
if "messages" not in st.session_state:
    st.session_state.messages = [{"role": "assistant", "content": "How can I help you today?"}]

# --- Display past chat messages ---
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# --- Input from user ---
if prompt := st.chat_input("Ask about an issue..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            if qa_chain:
                result = qa_chain.invoke({"query": prompt})
                response = result["result"]

                # Check if any documents were retrieved confidently
                if not result.get("source_documents"):
                    response = "⚠️ I couldn't find a confident match. Try rephrasing or check the caller/issue wording."
                else:
                    response += "\n\n**Sources Used:**"
                    for doc in result["source_documents"]:
                        score = doc.metadata.get("relevance_score", 0.0)
                        ticket = doc.metadata.get("Number", "N/A")
                        response += f"\n- Ticket no: {ticket} (Score: {score:.2f})"
            else:
                response = "🚫 The chatbot is not available due to a configuration error."

        st.markdown(response)
        st.session_state.messages.append({"role": "assistant", "content": response})
